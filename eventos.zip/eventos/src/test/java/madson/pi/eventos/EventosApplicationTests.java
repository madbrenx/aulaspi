package madson.pi.eventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
